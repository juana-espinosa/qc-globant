package Entities;

import java.util.ArrayList;

public class Familia {

    private String direccion;

    private Integer IDE;

    private Integer numeroLote;

    private String barrio;

    private String localidad;

    private ArrayList<Integrante> listaIntegrantes;

    private InformacionVivienda infoVivienda;
}
