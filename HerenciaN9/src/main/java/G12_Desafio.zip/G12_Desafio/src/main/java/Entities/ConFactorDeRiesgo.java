package Entities;

public class ConFactorDeRiesgo extends Familia {

    private Integer[] factores;
}
