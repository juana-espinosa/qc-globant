/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package APP;

/**
 *
 * @author brian
 */
public class G12_Desafio {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
