package Entities;

public class Adulto extends Joven {

    private boolean obraSocial;
}
