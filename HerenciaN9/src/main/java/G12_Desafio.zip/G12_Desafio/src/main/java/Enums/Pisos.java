package Enums;

public enum Pisos {

    MOSAICO, CEMENTO, TIERRA, OTROS
}
