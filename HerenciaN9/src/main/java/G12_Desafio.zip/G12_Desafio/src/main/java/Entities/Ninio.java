package Entities;

public class Ninio extends Integrante {
}
