package Entities;

public class ProblemaDeSalud {

    private Integer orden;

    private Integer IDE;

    private boolean HTA;

    private boolean DBT;
}
