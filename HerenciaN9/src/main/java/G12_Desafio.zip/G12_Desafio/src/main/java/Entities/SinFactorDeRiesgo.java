package Entities;


import Entities.Familia;

public class SinFactorDeRiesgo extends Familia {

    private boolean mejora;
}
