package Entities;

public class AbordajeNutricional {

    private Integer orden;

    private Integer edad;

    private Double peso;

    private boolean Eutrofico;

    private boolean bajoPeso;

    private boolean sobrePeso;

    public void untitledMethod() {
    }
}
