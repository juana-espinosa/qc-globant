package Entities;

import Enums.Paredes;
import Enums.Pisos;

public class InformacionVivienda {

    private Integer numeroDormitorios;

    private Paredes tipoParedes;

    private Pisos tipoPiso;

    private boolean Iluminacion;

    public void untitledMethod() {
    }
}
