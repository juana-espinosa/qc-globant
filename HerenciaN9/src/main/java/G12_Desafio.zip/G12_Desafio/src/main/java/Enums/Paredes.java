package Enums;

public enum Paredes {

    MATERIAL, MADERA, LATA, OTROS
}
