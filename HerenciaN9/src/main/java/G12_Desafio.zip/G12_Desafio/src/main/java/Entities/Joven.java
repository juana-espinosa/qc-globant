package Entities;

public class Joven extends Integrante {

    private boolean estudia;

    private boolean practicaDeporte;

    private boolean trabaja;
}
