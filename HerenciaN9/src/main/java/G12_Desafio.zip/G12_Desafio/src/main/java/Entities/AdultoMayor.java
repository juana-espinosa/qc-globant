package Entities;

public class AdultoMayor extends Integrante {

    private boolean jubilacion;
}
